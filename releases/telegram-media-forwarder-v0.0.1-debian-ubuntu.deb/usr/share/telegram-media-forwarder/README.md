# Telegram Media Forwarder v0.0.1

Aplicativo desktop em Python/Tkinter para encaminhamento autorizado de mídias do Telegram usando Telethon.

## Abrir

Depois de instalar:

```bash
telegram-media-forwarder
```

Ou procure por "Telegram Media Forwarder" no menu.

## Primeira execução

1. Preencha API ID e API Hash.
2. Clique em Login Telegram.
3. Informe telefone, código e senha 2FA se tiver.
4. Configure origem/destino.
5. Inicie o encaminhamento.

## Dados do usuário

Os dados pessoais ficam em:

```bash
~/.local/share/telegram-media-forwarder
```

Não compartilhe:
- sessao.session
- historico.txt
- config.json
