#!/usr/bin/env bash
set -euo pipefail

echo "==> Instalando ferramentas para criar RPM..."
sudo dnf install -y rpm-build rpmdevtools python3 python3-tkinter python3-pip

echo "==> Preparando ~/rpmbuild..."
rpmdev-setuptree

echo "==> Limpando builds antigos deste pacote..."
rm -f ~/rpmbuild/SOURCES/telegram-media-forwarder-0.0.1.tar.gz
rm -f ~/rpmbuild/SPECS/telegram-media-forwarder.spec
rm -f ~/rpmbuild/RPMS/noarch/telegram-media-forwarder-0.0.1-*.noarch.rpm

echo "==> Copiando fontes..."
cp "telegram-media-forwarder-0.0.1.tar.gz" ~/rpmbuild/SOURCES/
cp "telegram-media-forwarder.spec" ~/rpmbuild/SPECS/

echo "==> Construindo RPM..."
rpmbuild -ba ~/rpmbuild/SPECS/telegram-media-forwarder.spec

echo
echo "RPM gerado em:"
ls -lh ~/rpmbuild/RPMS/noarch/telegram-media-forwarder-0.0.1-6*.noarch.rpm

echo
echo "Agora instale com:"
echo "sudo dnf install ~/rpmbuild/RPMS/noarch/telegram-media-forwarder-0.0.1-6*.noarch.rpm"
echo
echo "Se faltar Telethon, instale com:"
echo "python3 -m pip install --user telethon"
