# Build RPM — Telegram Media Forwarder v0.0.1

Este pacote gera o RPM final v0.0.1 no Fedora.

## Como usar

```bash
cd ~/Downloads
tar -xzf telegram-media-forwarder-rpm-final-v001.tar.gz
cd telegram-media-forwarder-rpm-final-v001
./build-on-fedora.sh
```

Depois instale:

```bash
sudo dnf install ~/rpmbuild/RPMS/noarch/telegram-media-forwarder-0.0.1-6*.noarch.rpm
```

Abra com:

```bash
telegram-media-forwarder
```

## Observações

- A logo será instalada no app e como ícone do menu.
- `config.json`, `historico.txt` e `sessao.session` não entram no RPM.
- Esses dados serão criados em `~/.local/share/telegram-media-forwarder`.
- A tela de login do Telegram já está dentro do app.
