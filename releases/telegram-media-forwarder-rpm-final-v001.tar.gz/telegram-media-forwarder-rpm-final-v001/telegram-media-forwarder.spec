Name:           telegram-media-forwarder
Version:        0.0.1
Release:        6%{?dist}
Summary:        Desktop app para encaminhamento autorizado de mídias do Telegram

License:        MIT
BuildArch:      noarch
Source0:        %{name}-%{version}.tar.gz

Requires:       python3
Requires:       python3-tkinter

%description
Telegram Media Forwarder é uma interface desktop em Python/Tkinter para
encaminhamento autorizado de mídias do Telegram usando Telethon.

A versão 0.0.1 inclui interface profissional, tema claro/escuro, tela de login
do Telegram dentro do app, histórico para evitar duplicidades, changelog interno
e estrutura preparada para updates futuros.

Por segurança, dados do usuário como sessão, config e histórico ficam em:
~/.local/share/telegram-media-forwarder

%prep
%autosetup

%build
# Nada para compilar.

%install
mkdir -p %{buildroot}/usr/share/telegram-media-forwarder
install -m 0644 telegram_media_forwarder.py %{buildroot}/usr/share/telegram-media-forwarder/telegram_media_forwarder.py
install -m 0644 logo.png %{buildroot}/usr/share/telegram-media-forwarder/logo.png
install -m 0644 CHANGELOG.md %{buildroot}/usr/share/telegram-media-forwarder/CHANGELOG.md
install -m 0644 README.md %{buildroot}/usr/share/telegram-media-forwarder/README.md

mkdir -p %{buildroot}/usr/bin
install -m 0755 telegram-media-forwarder %{buildroot}/usr/bin/telegram-media-forwarder

mkdir -p %{buildroot}/usr/share/applications
install -m 0644 telegram-media-forwarder.desktop %{buildroot}/usr/share/applications/telegram-media-forwarder.desktop

mkdir -p %{buildroot}/usr/share/icons/hicolor/256x256/apps
install -m 0644 logo.png %{buildroot}/usr/share/icons/hicolor/256x256/apps/telegram-media-forwarder.png

%files
/usr/bin/telegram-media-forwarder
/usr/share/telegram-media-forwarder/telegram_media_forwarder.py
/usr/share/telegram-media-forwarder/logo.png
/usr/share/telegram-media-forwarder/CHANGELOG.md
/usr/share/telegram-media-forwarder/README.md
/usr/share/applications/telegram-media-forwarder.desktop
/usr/share/icons/hicolor/256x256/apps/telegram-media-forwarder.png

%changelog
* Sat May 23 2026 Bruno Vilela <brunovilela806@gmail.com> - 0.0.1-6
- Release final v0.0.1
- Adicionada tela de login Telegram dentro do app
- Adicionado changelog interno
- Mantidos dados pessoais fora do RPM
- Instala logo como recurso do app e ícone do menu
